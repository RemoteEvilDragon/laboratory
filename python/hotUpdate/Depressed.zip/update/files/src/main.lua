
function __G__TRACKBACK__(errorMessage)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(errorMessage) .. "\n")
    print(debug.traceback("", 2))
    print("----------------------------------------")

    buglyReportLuaException(errorMessage,debug.traceback())
    --在crashReport.mm文件中注册了lua堆栈中的函数集之一
end

package.path = package.path .. ";src/"



print(tostring(package.path))

	
cc.FileUtils:getInstance():setPopupNotify(false)

xpcall(function() require("app.MyApp").new():run() end, __G__TRACKBACK__)


