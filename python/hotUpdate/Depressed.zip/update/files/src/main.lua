
function __G__TRACKBACK__(errorMessage)
    print("----------------------------------------")
    print("LUA ERROR: " .. tostring(errorMessage) .. "\n")
    print(debug.traceback("", 2))
    print("----------------------------------------")

    buglyReportLuaException(errorMessage,debug.traceback())
    --在crashReport.mm文件中注册了lua堆栈中的函数集之一
end

package.path = package.path .. ";src/"

print(tostring(package.path))

cc.FileUtils:getInstance():setPopupNotify(false)

local function prepareUpdate()
	--清除旧的缓存目录，试用正确的目录begin
	local function getFileListFrom(directory)--TODO
    	local absoluteDir = cc.FileUtils:getInstance():fullPathForFilename(directory)
	    require 'lfs'
	    local fl = {}
	    for file in lfs.dir(absoluteDir) do
	        local fn = tostring(file)
	        if fn ~= "." and fn ~= ".."  then
	            table.insert(fl,absoluteDir..fn)
	        end
	    end
	    return fl
	end

	local curUpdateCache = cc.FileUtils:getInstance():getWritablePath() .."updateCache" .. luaGetAppVersion()
	local fileList = getFileListFrom(cc.FileUtils:getInstance():getWritablePath())
	for _,v in ipairs(fileList) do
	    local matchStr = string.match(v,"^.-updateCache.-$")
	    print (matchStr.." is matchStr")
	    print (curUpdateCache.." is curUpdateCache")
	    if matchStr and matchStr ~= curUpdateCache then
	    	print("print deleted file path "..v)
	    	cc.FileUtils:getInstance():removeDirectory(v.."/")
	    end
	end
	--清除旧的缓存目录，使用正确的目录end

	cc.FileUtils:getInstance():addSearchPath("src/")
	cc.FileUtils:getInstance():addSearchPath("res/")
	cc.FileUtils:getInstance():addSearchPath( curUpdateCache .."/src", true)
	cc.FileUtils:getInstance():addSearchPath( curUpdateCache .. "/res",true)
end

prepareUpdate()

-- local function checkContent()
-- 	local curUpdateCache = cc.FileUtils:getInstance():getWritablePath() .."updateCache" .. luaGetAppVersion()
--     local absoluteDir = cc.FileUtils:getInstance():fullPathForFilename(curUpdateCache)

--     require 'lfs'

--     local function checkDir(absoluteDir)
-- 		if cc.FileUtils:getInstance():isDirectoryExist(absoluteDir) then
-- 	    	for file in lfs.dir(absoluteDir) do
-- 		        local fn = tostring(file)
-- 		        if fn ~= "." and fn ~= ".."  then
-- 		            print (absoluteDir.." has got file "..fn)
-- 		        end
-- 		    end
-- 		else
-- 			print(absoluteDir.." doesn't exist.")
-- 		end
--     end

--     checkDir(absoluteDir)
--     checkDir(absoluteDir.."/src")
--     checkDir(absoluteDir.."/src/app/")
--     checkDir(absoluteDir.."/src/app/scenes")
-- end
-- checkContent()

xpcall(function() require("app.MyApp").new():checkUpdate() end, __G__TRACKBACK__)


