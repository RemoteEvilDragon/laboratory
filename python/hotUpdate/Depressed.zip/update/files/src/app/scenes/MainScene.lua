
local MainScene = class("MainScene", function()
    return display.newScene("MainScene")
end)

function MainScene:ctor()
	-- print(tostring(luaGetAppVersion()))--在cpp层注册全局lua函数成功
    cc.ui.UILabel.new({
            UILabelType = 2, text = "Check updating now 1.0.1.", size = 64})
        :align(display.CENTER, display.cx, display.cy)
        :addTo(self)

    require("app.updateManager")--热更新环境预处理
end

function MainScene:onEnter()
end

function MainScene:onExit()
end

return MainScene
