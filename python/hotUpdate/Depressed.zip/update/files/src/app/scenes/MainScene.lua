
local MainScene = class("MainScene", function()
    return display.newScene("MainScene")
end)

function MainScene:ctor()
	-- print(tostring(luaGetAppVersion()))--在cpp层注册全局lua函数成功
    cc.ui.UILabel.new({
            UILabelType = 2, text = "now 1.0.1.version", size = 64})
        :align(display.CENTER, display.cx, display.cy)
        :addTo(self)

 --    local curUpdateCache = cc.FileUtils:getInstance():getWritablePath() .."updateCache" .. luaGetAppVersion()
 --    local absoluteDir = cc.FileUtils:getInstance():fullPathForFilename(curUpdateCache)

 --    if cc.FileUtils:getInstance():isDirectoryExist(absoluteDir) then
	--     require 'lfs'
	--     for file in lfs.dir(absoluteDir) do
	--         local fn = tostring(file)
	--         if fn ~= "." and fn ~= ".."  then
	--             print (curUpdateCache.." has got file "..fn)
	--         end
	--     end
	-- else
	-- 	print(absoluteDir.." doesn't exist.")
	-- end
end

function MainScene:onEnter()
end

function MainScene:onExit()
end

return MainScene
