netWorkConfig = class("netWorkConfig")

netWorkConfig.isInHouse = false

function netWorkConfig:getHotUpdateUrl()
	if self.isInHouse then
		return "http://source.start.wang/client/resource/"
	else
		return "http://source.putao.com/client/resource/"
	end
end

function netWorkConfig:getServerNoticeConfig()
	local cfg = {SERVER_IP = "",SERVER_PORT=0}

	if self.isInHouse then
		cfg.SERVER_IP   = "10.1.11.31"
		cfg.SERVER_PORT = 8083
	else
		cfg.SERVER_IP   = CppUtils:getInstance():getHostByName("notice.putao.com")
		cfg.SERVER_PORT = 8040
	end

	return cfg
end

function netWorkConfig:getParCfgInitial( ... )
	if self.isInHouse then
		return "http://api.weidu.start.wang/get/configure"
	else
		return "http://api-weidu.putao.com/get/configure"
	end
end

function netWorkConfig:getQRcodeUrl()
	if self.isInHouse then
		return "http://api.weidu.start.wang/get/captcha"
	else
		return "http://api-weidu.putao.com/get/captcha"
	end
end

function netWorkConfig:getWeiDuReportUrl()
	if self.isInHouse then
		return "http://api.toy.weidu.start.wang/upload/data"
	else
		return "http://api-toy-weidu.putao.com/upload/data"
	end
end

return netWorkConfig