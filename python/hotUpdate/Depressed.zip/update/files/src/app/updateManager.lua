
--清除旧的缓存目录，试用正确的目录begin
local function getFileListFrom(directory)--TODO
    local absoluteDir = cc.FileUtils:getInstance():fullPathForFilename(directory)
    require 'lfs'
    local fl = {}
    for file in lfs.dir(absoluteDir) do
        local fn = tostring(file)
        if fn ~= "." and fn ~= ".."  then
            table.insert(fl,absoluteDir..fn)
        end
    end
    return fl
end

local curUpdateCache = cc.FileUtils:getInstance():getWritablePath() .."updateCache" .. luaGetAppVersion()

local fileList = getFileListFrom(cc.FileUtils:getInstance():getWritablePath())
for _,v in ipairs(fileList) do
    local matchStr = string.match(v,"^.-updateCache.-$")
    if matchStr and matchStr ~= currentUpdateCache then
    	print("print deleted file path "..v)
    	cc.FileUtils:getInstance():removeDirectory(v.."/")
    end
end
--清除旧的缓存目录，使用正确的目录end


--设置新文件保存的位置
local storagePath = curUpdateCache

--创建AssetsManagerEx对象
local assetsManagerEx = cc.AssetsManagerEx:create("src/version/project.manifest",storagePath)
assetsManagerEx:retain()

--设置下载消息listener
local function handleAssetsManagerEx(event)

        if (cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE == event:getEventCode()) then
            print("已经是最新版本了，进入游戏主界面")
            require("app.MyApp").new():run()
        end

        if (cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND == event:getEventCode()) then
            print("发现新版本，开始升级")
        end


        if (cc.EventAssetsManagerEx.EventCode.UPDATE_PROGRESSION == event:getEventCode()) then
            print("更新进度="..event:getPercent())
        end

        if (cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED == event:getEventCode()) then
            print("更新完毕，重新启动")
            require("app.MyApp").new():run()
        end
        
        if (cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST == event:getEventCode()) then
            print("发生错误:本地找不到manifest文件")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST == event:getEventCode()) then
            print("发生错误:下载manifest文件失败")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST == event:getEventCode()) then
            print("发生错误:解析manifest文件失败")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING == event:getEventCode()) then
            print("发生错误:更新失败")
        end
end

local dispatcher = cc.Director:getInstance():getEventDispatcher()
local eventListenerAssetsManagerEx = cc.EventListenerAssetsManagerEx:create(assetsManagerEx, handleAssetsManagerEx)
dispatcher:addEventListenerWithFixedPriority(eventListenerAssetsManagerEx, 1)

--检查版本并升级
assetsManagerEx:update()

