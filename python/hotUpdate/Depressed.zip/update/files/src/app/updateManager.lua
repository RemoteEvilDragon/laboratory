

--设置新文件保存的位置
local storagePath = cc.FileUtils:getInstance():getWritablePath() .."updateCache" .. luaGetAppVersion()

--创建AssetsManagerEx对象
local assetsManagerEx = cc.AssetsManagerEx:create("version/project.manifest",storagePath)
assetsManagerEx:retain()

--设置下载消息listener
local function handleAssetsManagerEx(event)

        if (cc.EventAssetsManagerEx.EventCode.ALREADY_UP_TO_DATE == event:getEventCode()) then
            print("已经是最新版本了，进入游戏主界面")
            require("app.MyApp").new():run()
        end

        if (cc.EventAssetsManagerEx.EventCode.NEW_VERSION_FOUND == event:getEventCode()) then
            print("发现新版本，开始升级")
        end


        if (cc.EventAssetsManagerEx.EventCode.UPDATE_PROGRESSION == event:getEventCode()) then
            print("更新进度="..event:getPercent())
        end

        if (cc.EventAssetsManagerEx.EventCode.UPDATE_FINISHED == event:getEventCode()) then
            print("更新完毕，重新启动")
            require("app.MyApp").new():run()
        end
        
        if (cc.EventAssetsManagerEx.EventCode.ERROR_NO_LOCAL_MANIFEST == event:getEventCode()) then
            print("发生错误:本地找不到manifest文件")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_DOWNLOAD_MANIFEST == event:getEventCode()) then
            print("发生错误:下载manifest文件失败")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_PARSE_MANIFEST == event:getEventCode()) then
            print("发生错误:解析manifest文件失败")
        end

        if (cc.EventAssetsManagerEx.EventCode.ERROR_UPDATING == event:getEventCode()) then
            print("发生错误:更新失败")
        end
end

local dispatcher = cc.Director:getInstance():getEventDispatcher()
local eventListenerAssetsManagerEx = cc.EventListenerAssetsManagerEx:create(assetsManagerEx, handleAssetsManagerEx)
dispatcher:addEventListenerWithFixedPriority(eventListenerAssetsManagerEx, 1)

--检查版本并升级
assetsManagerEx:update()

