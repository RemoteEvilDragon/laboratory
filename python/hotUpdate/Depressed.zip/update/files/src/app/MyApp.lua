
require("config")
require("cocos.init")
require("framework.init")

local MyApp = class("MyApp", cc.mvc.AppBase)

function MyApp:ctor()
    MyApp.super.ctor(self)
end

function MyApp:run()
	print("start to enter mainscene.")
	
    self:enterScene("MainScene")
end

function MyApp:checkUpdate()
    require("app.updateManager")--热更新环境预处理
end

return MyApp
