#!/usr/bin/env python

import platform

os_type = platform.system()

print os_type
